---
title: android bin kits
date: 2020-01-02 20:29:34
top: 95
tags:
- 工具
- 逆向
- Android
catagories: Android安全
---

## What？
android_bin kits是一个工具集，仅围绕一个目的进行：**分析Android系统中的可执行文件（dex、odex、oat、vdex）中有什么？**  
## Why？
Android native层代码经过编译后会有3种形式：静态库、动态库、elf可执行文件，而静态库最终会链接到动态库或可执行文件中去，最后android系统中native代码只会以动态库和elf可执行文件的形式存在，通过源码工程文件中的makefile、android.mk、android.bp等编译配置文件，我们可以精确的知道某个源码文件或某个函数最后会以什么样形式存在系统哪个文件中； <br/>  
**然而，你能通过java源码工程文件知道java代码最后会存在于系统中的哪个可执行文件中吗？**我们只能看到java类代码会被封装成哪个jar包，jar包会转成dex文件，然后android系统还会对dex文件进行优化，生成odex、oat、vdex、cdex、art之类文件。这一切都是android打包程序和dex优化程序做的手脚，那么想找出java源码与系统可执行文件的关系有两条路：研究android打包和优化原理，或逆向可执行文件获得想要的信息？  <br/>  
我选择使用后者方式去**实现java源码与可执行文件的关联。**因为android系统每个版本优化dex文件的机制和文件格式都会有所变化，这个打包和优化的过程也时刻在变。虽然逆向可执行文件也要面临同样的繁琐，但好在Android的各个阶段都有一些好的工具，我只需要利用他们实现我的目的。

## How ?
* ***adbtool.py*** 主要涉及一些用来和android系统交互的接口，用来做系统信息获取和文件拉取；
* ***android_bin.py*** 是对dex、odex、oat等文件进行分析，得到class、method、feilds、strings等信息，该脚本依赖开源工具[dextra](http://newandroidbook.com/tools/dextra.html)；
* ***vdex2dex.py*** 封装了android8/9 vdex抽取dex的工具，其所得dex文件可以使用android_bin进一步分析，该脚本依赖开源工具[vdexExtractor](https://github.com/anestisb/vdexExtractor)；
* ***filesystem_analyze.py*** 对整个安卓系统的可执行文件进行分析，也可以查询某个源码类被包含在哪个可执行文件中,该脚本依赖以上3个脚本。

## Usage  

* **1.拉取android系统所有可执行文件到文件夹android-8.0中**<br/>     
***filesystem_analyze.py -pull -o android-8.0***       
*/data/dalvik-cache/x86/system@app@Cube...lled. 2.7 MB/s (20904 bytes in 0.007s)
/system/app/Amaze/oat/x86/Amaze.vdex: ...ed. 8.4 MB/s (6111971 bytes in 0.692s)   
/system/app/BasicDreams/oat/x86/BasicD...lled. 1.6 MB/s (15795 bytes in 0.009s) 
Command 'adb pull /system/app/DeskClock/oat/x86/DeskClock.vdex android-8.0' time
d out after 2 seconds
pull /system/app/DeskClock/oat/x86/DeskClock.vdex faild, try again.*
  

* **2.对可执行文件系统进行分析，输出可执行文件包含java类信息到     android8-class.json文件中**<br/>   
***filesystem_analyze.py -class -i android-8.0 -o android8-class.json***   
```   
    "system@framework@boot-framework.vdex": {

        "AbstractAccountAuthenticator.java": "81",  
        "AbstractThreadedSyncAdapter.java": "1483",  
        "AccessibilityButtonController.java": "31",  
        "AccessibilityService.java": "48",  
        "AccessibilityServiceInfo.java": "57",    
        "AccountAndUser.java": "84",  
        "AccountManager.java": "128",  
        "AccountManagerCallback.java": "125",   
        "AccountManagerFuture.java": "89",   
        "AccountManagerInternal.java": "130",   
        
       }  
```
* **3.查询某个类文件包含在哪些可执行文件中**<br/>  
***filesystem_analyze.py -query -i android8-class.json --class-name ActivityManagerInternal.java***  
*precise match as follow:*   
*system@framework@boot-framework.vdex include ActivityManagerInternal.java*  
*boot-framework.vdex include ActivityManagerInternal.java*   

* **更多**   
执行python3 xxx.py，会打印readme。

## **作者声明**

    本文版权归作者所有，旨在技术交流使用。未经作者同意禁止转载，转载后需在文章页面明显位置给出原文连接，否则相关责任自行承担。
